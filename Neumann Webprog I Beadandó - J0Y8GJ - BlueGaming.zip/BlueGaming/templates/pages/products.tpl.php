<p><br/></p>
	<p><br/></p>
	<p><br/></p>

<div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-2 col-xs-12">
				<div id="get_category">
				</div>
				<!--Itt kerülnek elhelyezésre a kategóriák-->
				<div id="get_discount">
				<!--Itt kerülnek elhelyezésre az akciók-->
				</div>
			</div>
			<div class="col-md-8 col-xs-12">
				<div class="row">
					<div class="col-md-12 col-xs-12" id="product_msg">
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-heading">Termék kínálatunk</div>
					<div class="panel-body panel-img" style="background: #252525 !important;">
						<div id="get_product">
							<!--Itt kerülnek elhelyezésre a termékek-->
						</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>