<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
				<div class="row">
					<div class="col-md-12 col-xs-12">
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-heading">Elérhetőségeink</div>
					<div class="panel-body" style="background: #4D4A47  !important;">
						<h2 style="text-align: center; color: cyan">E-mail Elérhetőség: </h2><h3 style="text-align: center; color: cyan">bluegaming2023@gmail.com</h3>
						<br><br>
						<h2 style="text-align: center; color: cyan">Üzenet Küldése:</h2><br><br>
						<h3 style="text-align: center; color: cyan">Üzenet küldésére kizárólag regisztrált felhasználóink jogosultak!</h3>
						
					
				</div>
			</div>