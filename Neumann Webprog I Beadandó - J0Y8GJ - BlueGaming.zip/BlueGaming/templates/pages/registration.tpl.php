<p><br/></p>
	<p><br/></p>
	<p><br/></p>
<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="signup_msg">
				
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Regisztráció</div>
					<div class="panel-body" style="background: #4D4A47  !important;">
					
					<form id="signup_form" onsubmit="return false">
						<div class="row">
						<div class="col-md-6">
								<label for="f_name" style="color: blue">Vezetéknév</label>
								<input type="text" id="l_name" name="l_name"class="form-control" placeholder="Adja meg a vezetéknevét">
							</div>
							<div class="col-md-6">
								<label for="f_name" style="color: blue">Keresztnév</label>
								<input type="text" id="f_name" name="f_name" class="form-control" placeholder="Adja meg a keresztnevét">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="email" style="color: blue">E-mail cím</label>
								<input type="text" id="email" name="email"class="form-control" placeholder="Adja meg az e-mail címét">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="password" style="color: blue">Jelszó</label>
								<input type="password" id="password" name="password"class="form-control" placeholder="Adja meg a jelszavát (min. 9 karakter!)">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="repassword" style="color: blue">Jelszó megerősítése</label>
								<input type="password" id="repassword" name="repassword"class="form-control" placeholder="Adja meg a jelszóvát újra (min. 9 karakter!)">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="mobile" style="color: blue">Telefonszám</label>
								<input type="text" id="mobile" name="mobile"class="form-control" placeholder="pl. 06309647014">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="address1" style="color: blue">Lakcím (város, utca, házszám)</label>
								<input type="text" id="address1" name="address1"class="form-control" placeholder="Adja meg a lakcímét">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="address2" style="color: blue">Irányítószám</label>
								<input type="text" id="address2" name="address2"class="form-control" placeholder="Adja meg az irányítószámát">
							</div>
						</div>
						<p><br/></p>
						<div class="row">
							<div class="col-md-12">
								<input style="width:100%;" value="Regisztráció" type="submit" name="signup_button"class="btn btn-primary btn-lg">
							</div>
						</div>
						
					</div>
					</form>
					
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>